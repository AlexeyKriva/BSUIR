package com.example.relaxationnetwork.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class TextService {
    private final BinaryService binaryService;

    private final static int NUMBER_OF_NEURONES = 11;
    private final static int LETTER_BITS = 11;

    public List<List<Integer>> encodeText(String text) {
        StringBuilder binaryString = new StringBuilder();

        for (char letter : text.toCharArray()) {
            int letterIndex = getLetterIndex(letter);
            String binaryRepresentation = "0".repeat(LETTER_BITS - Integer.toBinaryString(letterIndex).length()) +
                    Integer.toBinaryString(letterIndex);

            binaryString.append(binaryRepresentation);
        }

        List<List<Integer>> textMatrix = new ArrayList<>();
        textMatrix.add(binaryService.convertToBinaryVector(
                "0".repeat(NUMBER_OF_NEURONES - binaryString.length()) + binaryString.toString()
        ));

        return textMatrix;
    }

    public int getLetterIndex(char letter) {
        //System.out.println(letter + " : " + (int) letter);
        return letter;
    }

    public String decodeText(List<List<Integer>> binaryText) {
        binaryText.set(0, binaryText.get(0).subList(0, binaryText.get(0).size()));
        List<List<Integer>> subBinary = Stream.iterate(0, i -> i + LETTER_BITS)
                .limit(NUMBER_OF_NEURONES / LETTER_BITS)
                .map(i -> binaryText.get(0).subList(i, Math.min(i + LETTER_BITS, NUMBER_OF_NEURONES)))
                .toList();

        StringBuilder sourceText = new StringBuilder();

        for (List<Integer> binaryLetter : subBinary) {
            StringBuilder letter = new StringBuilder();

            for (int bite : binaryLetter) {
                letter.append(bite);
            }

            int letterIndex = Integer.parseInt(letter.toString().replaceAll("-1", "0"), 2);

            if (letterIndex > 0) {
                sourceText.append(getLetterByIndex(letterIndex));
            }
        }

        return sourceText.toString();
    }

    private char getLetterByIndex(int index) {
        return (char) index;
    }
}