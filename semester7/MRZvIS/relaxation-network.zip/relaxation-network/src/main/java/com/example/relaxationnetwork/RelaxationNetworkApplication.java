package com.example.relaxationnetwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelaxationNetworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(RelaxationNetworkApplication.class, args);
    }

}
