package com.example.relaxationnetwork.services;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service()
@RequiredArgsConstructor
public class RelaxationNetwork {
    private final MatrixService matrixService;
    private final TextService textService;

    private List<List<Integer>> weights;
    private List<List<Integer>> rusMatrix;
    private List<List<Integer>> engMatrix;

    private final int MAX_ITER = 50;

    public List<List<Integer>> train(String russian, String english) {
        rusMatrix = textService.encodeText(russian);
        engMatrix = textService.encodeText(english);

        matrixService.print(rusMatrix);
        matrixService.print(engMatrix);

//        System.out.println("Russian: " + textService.decodeText(rusMatrix));
//        System.out.println("English: " + textService.decodeText(engMatrix));

        weights = matrixService.multiply(matrixService.transpose(rusMatrix), engMatrix);

        matrixService.print(weights);

        return weights;
    }

    public Map<String, String> forward(String russian) {
        if (weights.isEmpty()) {
            throw new RuntimeException("Матрица весов не инициализирована!!!");
        }

        List<List<Integer>> engPredicte = new ArrayList<>();
        List<List<Integer>> rusPredicte = textService.encodeText(russian);

        matrixService.print(rusPredicte);

        int i = 0;
        while (i < MAX_ITER) {
            engPredicte = matrixService.multiplyWithActivation(rusPredicte, weights);

            if (isTextsMatched(engPredicte, engMatrix)) {// && isImagesMatched(backOutput, matrixService.transpose(pixelValues))) {
                String targetText = textService.decodeText(engPredicte);
                //String sourceText = textService.decodeText(encodedText);

                return Map.of(russian, targetText);
            }

            System.out.println(i);

            rusPredicte = matrixService.multiplyWithActivation(engPredicte, matrixService.transpose(weights));
            i++;
        }

        System.out.println("Russia predicte: " + rusPredicte);
        System.out.println("English predicte: " + engPredicte);

        return null;
    }

    public boolean isTextsMatched(List<List<Integer>> predicted, List<List<Integer>> reference) {
        int coincidence = 0;

        for (int i = 0; i < predicted.get(0).size(); i++) {
            if (reference.get(0).get(i).equals(predicted.get(0).get(i))) {
                coincidence++;
            }
        }

        return predicted.get(0).size() == reference.get(0).size() && coincidence == reference.get(0).size();
    }

    public Map<String, String> backward(String english) {
        return Map.of();
    }

    public void test(String text) {
        //System.out.println("Size: " + text.length());
        for (char a: text.toCharArray()) {
            textService.getLetterIndex(a);
        }
    }
}