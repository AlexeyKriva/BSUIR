package com.example.relaxationnetwork.controllers;

import com.example.relaxationnetwork.entities.AssociationPair;
import com.example.relaxationnetwork.services.RelaxationNetwork;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class RelaxationNetworkController {
    private final RelaxationNetwork relaxationNetwork;

    @PostMapping("/train")
    public List<List<Integer>> train(
            @RequestParam("russian") String russian,
            @RequestParam("english") String english
    ) {
        return relaxationNetwork.train(russian, english);
    }

    @PostMapping("/forward")
    public Map<String, String> forward(@RequestParam("russian") String russian) {
        return relaxationNetwork.forward(russian);
    }

    @PostMapping("/backward")
    public Map<String, String> backward(@RequestParam("english") String english) {
        return relaxationNetwork.backward(english);
    }

    @PostMapping("/test")
    public void test(@RequestParam("russian") String text) {
        relaxationNetwork.test(text);
    }
}