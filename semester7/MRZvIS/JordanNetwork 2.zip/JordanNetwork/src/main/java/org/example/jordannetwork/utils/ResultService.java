package org.example.jordannetwork.utils;

import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ResultService {
    public static Map<String, String> buildResult(List<Double> sequence, List<Double> nextNumbers,
                                           List<Double> predictedNumbers, int step, int windowSize, double
                                                          sumOfDoubleDiff) {
        Map<String, String> result = new LinkedHashMap<>();

        int numberOfWindow = 1;

        for (int i = 0; i < sequence.size() - windowSize; i += windowSize) {
            result.put("окно " + numberOfWindow, sequence.subList(i, i + windowSize).toString());
            result.put("ожидаемые значения " + numberOfWindow, nextNumbers.subList(i, i + windowSize).toString());
            result.put("предсказанные значения " + (numberOfWindow++),
                    predictedNumbers.subList(i, i + windowSize).toString());
        }

        result.put("количество итераций", String.valueOf(step));
        result.put("абсолютная средняя ошибка", sumOfDoubleDiff + "%");

        return result;
    }
}