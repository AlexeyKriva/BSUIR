/*
Лабораторная работа №3 по дисциплине МРЗВИС
Выполнена студентом группы 121702 БГУИР Кривецким Алексеем Эдуардовичем
Вариант 1: Реализовать модель сети Джордана с логарифмической функцией активации (гиперболический арксинус)
*/
package org.example.jordannetwork.network;

import lombok.RequiredArgsConstructor;
import org.example.jordannetwork.annotations.NetworkParam;
import org.example.jordannetwork.annotations.NeuroneLayerParam;
import org.example.jordannetwork.annotations.SequenceParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.example.jordannetwork.utils.MatrixService.*;
import static org.example.jordannetwork.utils.ResultService.buildResult;
import static org.example.jordannetwork.utils.SimpleMathService.roundToPrecision;

import org.example.jordannetwork.utils.SequenceGenerator;


@Service
@RequiredArgsConstructor
public class JordanNetwork {
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    //Services
    private final SequenceGenerator sequenceGenerator;

    //Layers constants
    private final int INPUT_NEURONES = 1;
    private final int HIDDEN_NEURONES = 5;
    private final int OUTPUT_NEURONES = 1;
    private final int MEMORY_NEURONES = OUTPUT_NEURONES;

    //General network constants
    private final double LEARNING_RATE = 0.00000001;
    private final int NUMBER_OF_WEIGHT_MATRICES = 3;
    private final double NORMAL_COEF = 10;
    private final int MAX_NUMBER_OF_EPOCHS = 1500000;

    //Sequence constants
    private final int LEFT_SEQUENCE_BOARD = 0;
    private final int RIGHT_SEQUENCE_BOARD = 9;
    private final int WINDOW_SIZE = 2;

    //Other constants
    private final double MAX_ERROR = 0.1;
    private final double EPS = 1e-8;

    private List<List<List<Double>>> weights = new ArrayList<>();

    public static double total = 0;

    public Map<String, String> predict() {
        List<Double> generalSequence = sequenceGenerator.generateDoubleSequenceByNumberAndIndexes(1,
                LEFT_SEQUENCE_BOARD, RIGHT_SEQUENCE_BOARD);

        List<List<Double>> memory = initMemory();

        List<Double> predictedNumbers = new ArrayList<>();

        double sumOfDoubleDiff = 0;

        for (int i = 0; i < generalSequence.size() - WINDOW_SIZE; i++) {
            List<List<List<Double>>> hiddenAndOutput = new ArrayList<>();
            List<Double> window = generalSequence.subList(i, i + WINDOW_SIZE);
            List<Double> target = generalSequence.subList(i + WINDOW_SIZE, i + WINDOW_SIZE + 1);

            for (int j = 0; j < window.size(); j++) {
                List<List<Double>> windowSlice = new ArrayList<>(Arrays.asList(Arrays.asList(window.get(j))));
                hiddenAndOutput = propagateForward(windowSlice, memory);
                memory = hiddenAndOutput.get(1);
            }

            predictedNumbers.add(hiddenAndOutput.get(1).get(0).get(0));

            sumOfDoubleDiff = 0;

            for (int j = 0; j < predictedNumbers.size(); j++) {
                sumOfDoubleDiff += Math.abs((generalSequence.subList(WINDOW_SIZE, generalSequence.size()).get(j) -
                        predictedNumbers.get(j)) / (generalSequence.subList(WINDOW_SIZE, generalSequence.size()).get(j)
                        + EPS));
            }

            sumOfDoubleDiff = sumOfDoubleDiff / generalSequence.subList(WINDOW_SIZE, generalSequence.size()).size() * 100.0;

            System.out.println("sumOfDoubleDiff="+sumOfDoubleDiff);
        }

        return buildResult(generalSequence, generalSequence.subList(WINDOW_SIZE, generalSequence.size()),
                predictedNumbers, 1, WINDOW_SIZE, sumOfDoubleDiff);
    }

    public List<List<Double>> initMemory() {
        List<List<Double>> memory = new ArrayList<>();

        memory.add(new ArrayList<>());

        for (int i = 0; i < MEMORY_NEURONES; i++) {
            memory.get(0).add(0.0);
        }

        return memory;
    }

    public void initWeights() {
        for (int layer = 0; layer < NUMBER_OF_WEIGHT_MATRICES; layer++) {
            List<List<Double>> weightMatrix = new ArrayList<>();

            if (layer == 0) {
                for (int i = 0; i < HIDDEN_NEURONES; i++) {
                    weightMatrix.add(new ArrayList<>());

                    for (int j = 0; j < INPUT_NEURONES; j++) {
                        weightMatrix.get(i).add(roundRandomWeight());
                    }
                }
            } else if (layer == 1) {
                for (int i = 0; i < HIDDEN_NEURONES; i++) {
                    weightMatrix.add(new ArrayList<>());

                    for (int j = 0; j < MEMORY_NEURONES; j++) {
                        weightMatrix.get(i).add(roundRandomWeight());
                    }
                }
            } else {
                for (int i = 0; i < OUTPUT_NEURONES; i++) {
                    weightMatrix.add(new ArrayList<>());

                    for (int j = 0; j < HIDDEN_NEURONES; j++) {
                        weightMatrix.get(i).add(roundRandomWeight());
                    }
                }
            }
            weights.add(weightMatrix);
        }
    }

    public double roundRandomWeight() {
        Random random = new Random();

        double randomWeight = -1 + (1 - -1) * random.nextDouble();

        return roundToPrecision(randomWeight);
    }

    public Map<String, String> train() {
        initWeights();

        int epoch = 1;

        List<Double> generalSequence = sequenceGenerator.generateDoubleSequenceByNumberAndIndexes(0,
                LEFT_SEQUENCE_BOARD, RIGHT_SEQUENCE_BOARD);

        List<List<Double>> memory = initMemory();

        List<Double> totalPredictedNumbers = new ArrayList<>();

        double sumOfDoubleDiff = 0;

        while (epoch <= MAX_NUMBER_OF_EPOCHS) {
            List<List<List<Double>>> hiddenAndOutput = new ArrayList<>();

            List<Double> currentPredictedNumbers = new ArrayList<>();

            for (int i = 0; i < generalSequence.size() - WINDOW_SIZE; i++) {
                List<Double> window = generalSequence.subList(i, i + WINDOW_SIZE);
                List<Double> target = generalSequence.subList(i + WINDOW_SIZE, i + WINDOW_SIZE + 1);

                for (int j = 0; j < window.size(); j++) {
                    List<List<Double>> windowSlice = new ArrayList<>(Arrays.asList(Arrays.asList(window.get(j))));
                    hiddenAndOutput = propagateForward(windowSlice, memory);
                    memory = hiddenAndOutput.get(1);
                }

                currentPredictedNumbers.add(hiddenAndOutput.get(1).get(0).get(0));

                List<List<Double>> error = Arrays.asList(Arrays.asList(2 * (memory.get(0).get(0) - target.get(0))
                        / OUTPUT_NEURONES));

                propagateBackward(hiddenAndOutput, error, Arrays.asList(Arrays.asList(window.get(window.size() - 1))),
                        memory);
            }

            double totalError = 0;

            for (int i = 0; i < generalSequence.size() - WINDOW_SIZE; i++) {
                List<Double> target = generalSequence.subList(i + WINDOW_SIZE, i + WINDOW_SIZE + 1);

                double currentTotalError = 0;
                for (int j = 0; j < target.size(); j++) {
                    currentTotalError += hiddenAndOutput.get(1).get(0).get(j) - target.get(j);
                }

                currentTotalError /= target.size();

                totalError += currentTotalError;
            }

            totalPredictedNumbers = currentPredictedNumbers;
            epoch++;

            sumOfDoubleDiff = 0;

            for (int i = 0; i < totalPredictedNumbers.size(); i++) {
                sumOfDoubleDiff += Math.abs((generalSequence.subList(WINDOW_SIZE, generalSequence.size()).get(i) -
                        totalPredictedNumbers.get(i)) / (generalSequence.subList(WINDOW_SIZE, generalSequence.size()).get(i)
                        +EPS));
            }

            sumOfDoubleDiff = sumOfDoubleDiff / generalSequence.subList(WINDOW_SIZE, generalSequence.size()).size() * 100.0;

            total += sumOfDoubleDiff;

            if (epoch % 1000 == 0) {
                System.out.println("epoch=" + epoch);
                System.out.println("sumOfDoubleDiff=" + sumOfDoubleDiff);
            }

            double loss = 0.0;

            for (int i = 0; i < generalSequence.size() - WINDOW_SIZE; i++) {
                loss += Math.pow(generalSequence.subList(WINDOW_SIZE, generalSequence.size()).get(i) -
                        totalPredictedNumbers.get(i), 2);
            }

            if (sumOfDoubleDiff <= MAX_ERROR) {
                System.out.println("sumOfDoubleDiff="+sumOfDoubleDiff);
                break;
            }
        }

        System.out.println("total=" + (total / epoch));

        return buildResult(generalSequence, generalSequence.subList(WINDOW_SIZE, generalSequence.size()),
                totalPredictedNumbers, epoch, WINDOW_SIZE, total / epoch);
    }

    public List<List<List<Double>>> propagateForward(List<List<Double>> windowSlice, List<List<Double>> memory) {
        windowSlice.set(0, windowSlice.get(0).stream()
                .map(num -> num / NORMAL_COEF).collect(Collectors.toCollection(ArrayList::new)));

        List<List<Double>> hiddenInput = multiplyMatrix(weights.get(0), windowSlice);
        List<List<Double>> hiddenMemory = multiplyMatrix(weights.get(1), memory);
        List<List<Double>> hidden = sumMatrix(hiddenInput, hiddenMemory);

        List<List<Double>> hiddenAfterActivation = new ArrayList<>();

        for (int i = 0; i < hidden.size(); i++) {
            hiddenAfterActivation.add(new ArrayList<>());
            for (int j = 0; j < hidden.get(i).size(); j++) {
                hiddenAfterActivation.get(i).add(activation(hidden.get(i).get(j)));
            }
        }

        List<List<Double>> output = multiplyMatrix(weights.get(2), hiddenAfterActivation);

        output.get(0).set(0, output.get(0).get(0) * NORMAL_COEF);

        return List.of(hiddenAfterActivation, output, hidden);
    }

    public double propagateBackward(List<List<List<Double>>> hiddenAndOutput, List<List<Double>> error,
                                    List<List<Double>> window, List<List<Double>> memory) {
        List<List<Double>> hiddenOutputWeights = multiplyMatrix(error, transposeMatrix(hiddenAndOutput.get(0)));

        List<List<Double>> hiddenDerivatives = new ArrayList<>();

        for (int i = 0; i < hiddenAndOutput.get(2).size(); i++){
            hiddenDerivatives.add(new ArrayList<>());
            for (int j = 0; j < hiddenAndOutput.get(2).get(0).size(); j++) {
                hiddenDerivatives.get(i).add(activationDerivative(hiddenAndOutput.get(2).get(i).get(j)));
            }
        }

        List<List<Double>> matrixElementByElement = multiplyMatrixElementByElement(
                multiplyMatrix(transposeMatrix(weights.get(2)), error),
                hiddenDerivatives
        );

        List<List<Double>> inputHiddenWeights = multiplyMatrix(
                matrixElementByElement,
                transposeMatrix(window)
        );

        List<List<Double>> memoryHiddenWeights = multiplyMatrix(
                matrixElementByElement,
                transposeMatrix(memory)
        );

        weights.set(0, subtractMatrix(weights.get(0), multiplyByNumber(inputHiddenWeights, LEARNING_RATE)));
        weights.set(1, subtractMatrix(weights.get(1), multiplyByNumber(memoryHiddenWeights, LEARNING_RATE)));
        weights.set(2, subtractMatrix(weights.get(2), multiplyByNumber(hiddenOutputWeights, LEARNING_RATE)));

        return 0.0;
    }

    public double activation(double x) {
        return Math.log(x + Math.sqrt(x * x + 1));
    }

    public double activationDerivative(double x) {
        return 1 / Math.sqrt(x * x + 1);
    }
}