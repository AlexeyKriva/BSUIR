/*
Лабораторная работа №1 по дисциплине МРЗВИС
Выполнена студентом группы 121702 БГУИР Кривецким Алексеем Эдуардовичем
Вариант 1: Реализовать модель линейной рециркуляционной сети с постоянным коэффициентом обучения с ненормированными весами
*/
package com.software.bsuir.multilayerneuralnetwork.exceptions;

public class RecirculationNetworkIsNotInitException extends RuntimeException {
    public RecirculationNetworkIsNotInitException(String message) {
        super(message);
    }
}
