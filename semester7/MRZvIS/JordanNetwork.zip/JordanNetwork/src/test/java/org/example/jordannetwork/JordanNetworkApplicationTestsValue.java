package org.example.jordannetwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JordanNetworkApplicationTestsValue {

    @Test
    void contextLoads() {
    }

}
