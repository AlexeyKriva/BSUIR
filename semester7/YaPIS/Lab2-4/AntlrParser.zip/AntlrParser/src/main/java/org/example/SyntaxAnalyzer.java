package org.example;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SyntaxAnalyzer {
    public static final String PATH = "src/main/java/org/example/test.keva";

    public static void main(String[] args) {
        try {
            String input = readCodeFromKevaFile();

            //System.out.println(input);

            ANTLRInputStream inputStream = new ANTLRInputStream(input);
            MyLexer lexer = new MyLexer(inputStream);

            CommonTokenStream tokens = new CommonTokenStream(lexer);

            MyParser parser = new MyParser(tokens);


            ParseTree tree = parser.program();

            System.out.println("Parse Tree: \n" + tree.toStringTree(parser));
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
    }

    public static String readCodeFromKevaFile() throws IOException {
        return Files.readString(Path.of(PATH));
    }
}